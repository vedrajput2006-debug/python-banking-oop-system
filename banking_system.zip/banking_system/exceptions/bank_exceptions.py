"""
Custom exception hierarchy for the banking system.

Using dedicated exception classes (instead of generic ValueError/Exception)
is a clean-code practice: it lets callers catch specific failure modes and
makes error handling self-documenting.
"""


class BankError(Exception):
    """Base class for all banking-related errors."""
    pass


class InvalidAmountError(BankError):
    """Raised when an amount is zero, negative, or otherwise invalid."""
    pass


class InsufficientFundsError(BankError):
    """Raised when a withdrawal/transfer exceeds the available balance."""
    pass


class AccountNotFoundError(BankError):
    """Raised when an operation references an account that doesn't exist."""
    pass


class DuplicateAccountError(BankError):
    """Raised when trying to create an account with an ID that already exists."""
    pass
