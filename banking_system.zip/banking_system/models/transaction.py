"""
Transaction: an immutable record of a single event on an account.

Immutability (no setters, values fixed at construction) protects the
integrity of the transaction history — once something happened, it
can't be silently rewritten.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import uuid


class TransactionType(Enum):
    DEPOSIT = "DEPOSIT"
    WITHDRAWAL = "WITHDRAWAL"
    TRANSFER_IN = "TRANSFER_IN"
    TRANSFER_OUT = "TRANSFER_OUT"
    INTEREST = "INTEREST"
    FEE = "FEE"


@dataclass(frozen=True)
class Transaction:
    account_id: str
    type: TransactionType
    amount: float
    balance_after: float
    timestamp: datetime = field(default_factory=datetime.now)
    transaction_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    description: str = ""

    def __str__(self) -> str:
        ts = self.timestamp.strftime("%Y-%m-%d %H:%M:%S")
        sign = "+" if self.type in (
            TransactionType.DEPOSIT,
            TransactionType.TRANSFER_IN,
            TransactionType.INTEREST,
        ) else "-"
        return (
            f"[{ts}] {self.transaction_id} | {self.type.value:<13} "
            f"{sign}{self.amount:>10.2f} | balance: {self.balance_after:>10.2f}"
            f"{' | ' + self.description if self.description else ''}"
        )
