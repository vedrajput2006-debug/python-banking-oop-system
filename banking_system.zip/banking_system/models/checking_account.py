from __future__ import annotations
from exceptions import InvalidAmountError, InsufficientFundsError
from models.account import Account
from models.transaction import Transaction, TransactionType


class CheckingAccount(Account):
    """
    No interest. Allows spending into a small overdraft limit, and
    charges a flat monthly maintenance fee.
    """

    def __init__(self, owner_name: str, initial_balance: float = 0.0,
                 overdraft_limit: float = 200.0, monthly_fee: float = 5.0):
        super().__init__(owner_name, initial_balance)
        self.overdraft_limit = overdraft_limit
        self.monthly_fee = monthly_fee

    def withdraw(self, amount: float, description: str = "") -> Transaction:
        if amount <= 0:
            raise InvalidAmountError("Withdrawal amount must be positive.")
        if self.balance - amount < -self.overdraft_limit:
            raise InsufficientFundsError(
                f"Withdrawal exceeds overdraft limit of {self.overdraft_limit:.2f}."
            )
        self._adjust_balance(-amount)
        return self._record(TransactionType.WITHDRAWAL, amount, description)

    def apply_monthly_effect(self) -> Transaction | None:
        if self.monthly_fee <= 0:
            return None
        self._adjust_balance(-self.monthly_fee)
        return self._record(TransactionType.FEE, self.monthly_fee, "Monthly maintenance fee")
