"""
Account: abstract base class for all account types.

OOP principles demonstrated here:
- Abstraction: Account defines *what* every account can do
  (deposit, withdraw, apply_monthly_effect) without fixing *how* every
  subtype does it. It cannot be instantiated directly (ABC).
- Encapsulation: the balance is a "private" attribute (name-mangled with
  a double underscore) and can only be changed through controlled
  methods that validate input and log a Transaction. No outside code
  can do `account.__balance = -1000`.
- Polymorphism: subclasses override `withdraw` and `apply_monthly_effect`
  with type-specific rules, but calling code just calls `account.withdraw(x)`
  regardless of the concrete type.
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from datetime import datetime
from typing import List
import itertools

from exceptions import InvalidAmountError, InsufficientFundsError
from models.transaction import Transaction, TransactionType


class Account(ABC):
    """Abstract base class. Cannot be instantiated on its own."""

    _id_counter = itertools.count(1001)

    def __init__(self, owner_name: str, initial_balance: float = 0.0):
        if initial_balance < 0:
            raise InvalidAmountError("Initial balance cannot be negative.")

        self._account_id = f"ACC{next(Account._id_counter)}"
        self._owner_name = owner_name
        self.__balance = float(initial_balance)          # encapsulated state
        self._created_at = datetime.now()
        self._history: List[Transaction] = []

        if initial_balance > 0:
            self._record(TransactionType.DEPOSIT, initial_balance, "Opening balance")

    # ---- read-only public views of internal state (encapsulation) ----
    @property
    def account_id(self) -> str:
        return self._account_id

    @property
    def owner_name(self) -> str:
        return self._owner_name

    @property
    def balance(self) -> float:
        return self.__balance

    @property
    def history(self) -> List[Transaction]:
        return list(self._history)  # return a copy, not the live list

    # ---- protected helper used by subclasses, not by outside callers ----
    def _record(self, ttype: TransactionType, amount: float, description: str = "") -> Transaction:
        tx = Transaction(
            account_id=self._account_id,
            type=ttype,
            amount=amount,
            balance_after=self.__balance,
            description=description,
        )
        self._history.append(tx)
        return tx

    def _adjust_balance(self, delta: float) -> None:
        """The only place __balance is ever mutated."""
        self.__balance = round(self.__balance + delta, 2)

    # ---- shared, concrete behavior ----
    def deposit(self, amount: float, description: str = "") -> Transaction:
        if amount <= 0:
            raise InvalidAmountError("Deposit amount must be positive.")
        self._adjust_balance(amount)
        return self._record(TransactionType.DEPOSIT, amount, description)

    # ---- behavior every subclass MUST provide its own version of ----
    @abstractmethod
    def withdraw(self, amount: float, description: str = "") -> Transaction:
        """Withdraw money. Rules differ per account type (see subclasses)."""
        raise NotImplementedError

    @abstractmethod
    def apply_monthly_effect(self) -> Transaction | None:
        """Interest credit, maintenance fee, etc. — one line per account type."""
        raise NotImplementedError

    def __str__(self) -> str:
        return (f"{self.__class__.__name__} {self._account_id} "
                f"({self._owner_name}) — balance: {self.__balance:.2f}")
