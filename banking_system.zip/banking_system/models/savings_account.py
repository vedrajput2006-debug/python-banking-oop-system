from __future__ import annotations
from exceptions import InvalidAmountError, InsufficientFundsError
from models.account import Account
from models.transaction import Transaction, TransactionType


class SavingsAccount(Account):
    """
    Earns monthly interest. No withdrawal is allowed to take the
    balance below a minimum required balance.
    """

    def __init__(self, owner_name: str, initial_balance: float = 0.0,
                 interest_rate: float = 0.03, minimum_balance: float = 100.0):
        super().__init__(owner_name, initial_balance)   # inheritance in action
        self.interest_rate = interest_rate               # annual rate, e.g. 0.03 = 3%
        self.minimum_balance = minimum_balance

    def withdraw(self, amount: float, description: str = "") -> Transaction:
        if amount <= 0:
            raise InvalidAmountError("Withdrawal amount must be positive.")
        if self.balance - amount < self.minimum_balance:
            raise InsufficientFundsError(
                f"Withdrawal would breach minimum balance of {self.minimum_balance:.2f}."
            )
        self._adjust_balance(-amount)
        return self._record(TransactionType.WITHDRAWAL, amount, description)

    def apply_monthly_effect(self) -> Transaction | None:
        interest = round(self.balance * (self.interest_rate / 12), 2)
        if interest <= 0:
            return None
        self._adjust_balance(interest)
        return self._record(TransactionType.INTEREST, interest, "Monthly interest")
