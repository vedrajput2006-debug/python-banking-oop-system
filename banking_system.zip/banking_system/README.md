# Python Banking System

A small, dependency-free banking system built to demonstrate core
object-oriented programming principles in Python: **encapsulation,
inheritance, polymorphism, abstraction**, and clean-code practices
(single responsibility, custom exceptions, immutable records).

## Features

- Open **Savings** or **Checking** accounts
- Deposit, withdraw, and transfer between accounts
- Full, immutable transaction history per account
- Type-specific rules via polymorphism:
  - Savings: monthly interest, enforced minimum balance
  - Checking: overdraft limit, monthly maintenance fee
- Custom exception hierarchy for precise error handling
- Unit test suite (`unittest`, stdlib only — no external dependencies)

## Project Structure

```
banking_system/
├── bank.py                    # Bank facade: opens accounts, routes operations
├── main.py                    # Runnable demo
├── models/
│   ├── account.py             # Abstract base class Account (ABC)
│   ├── savings_account.py     # SavingsAccount(Account)
│   ├── checking_account.py    # CheckingAccount(Account)
│   └── transaction.py         # Immutable Transaction record (frozen dataclass)
├── exceptions/
│   └── bank_exceptions.py     # BankError and subclasses
├── tests/
│   └── test_bank.py           # Unit tests
└── README.md
```

## Class Diagram

```mermaid
classDiagram
    class Account {
        <<abstract>>
        -str _account_id
        -str _owner_name
        -float __balance
        -datetime _created_at
        -list~Transaction~ _history
        +account_id() str
        +owner_name() str
        +balance() float
        +history() list~Transaction~
        +deposit(amount, description) Transaction
        #_adjust_balance(delta) void
        #_record(type, amount, description) Transaction
        +withdraw(amount, description)* Transaction
        +apply_monthly_effect()* Transaction
    }

    class SavingsAccount {
        +float interest_rate
        +float minimum_balance
        +withdraw(amount, description) Transaction
        +apply_monthly_effect() Transaction
    }

    class CheckingAccount {
        +float overdraft_limit
        +float monthly_fee
        +withdraw(amount, description) Transaction
        +apply_monthly_effect() Transaction
    }

    class Transaction {
        <<frozen dataclass>>
        +str transaction_id
        +str account_id
        +TransactionType type
        +float amount
        +float balance_after
        +datetime timestamp
        +str description
    }

    class TransactionType {
        <<enumeration>>
        DEPOSIT
        WITHDRAWAL
        TRANSFER_IN
        TRANSFER_OUT
        INTEREST
        FEE
    }

    class Bank {
        -str name
        -dict~str, Account~ _accounts
        +open_account(owner, kind, balance) Account
        +get_account(account_id) Account
        +deposit(account_id, amount) Transaction
        +withdraw(account_id, amount) Transaction
        +transfer(from_id, to_id, amount) tuple
        +statement(account_id) list~Transaction~
        +apply_month_end() list~Transaction~
        +total_assets() float
    }

    class BankError {
        <<exception>>
    }
    class InvalidAmountError
    class InsufficientFundsError
    class AccountNotFoundError
    class DuplicateAccountError

    Account <|-- SavingsAccount : inherits
    Account <|-- CheckingAccount : inherits
    Account "1" *-- "many" Transaction : creates & owns
    Transaction --> TransactionType : has a
    Bank "1" o-- "many" Account : manages
    BankError <|-- InvalidAmountError
    BankError <|-- InsufficientFundsError
    BankError <|-- AccountNotFoundError
    BankError <|-- DuplicateAccountError
```

## OOP Principles — Where and Why

| Principle | Where it lives | Why it's used |
|---|---|---|
| **Encapsulation** | `Account.__balance` is name-mangled and only ever changed through `_adjust_balance()`, called from validated methods like `deposit`/`withdraw`. `history` returns a *copy* of the list. | Prevents any code from setting a negative or arbitrary balance, or silently rewriting the transaction ledger. |
| **Abstraction** | `Account` is an `ABC` with abstract methods `withdraw()` and `apply_monthly_effect()`. It can't be instantiated directly. | Callers (`Bank`, `main.py`) only need to know "every account can be withdrawn from and has a month-end effect" — not the mechanics of each type. |
| **Inheritance** | `SavingsAccount` and `CheckingAccount` both extend `Account`, reusing `deposit()`, `history`, `_record()`, etc. | Avoids duplicating shared behavior; each subclass only adds what's actually different. |
| **Polymorphism** | `Bank.apply_month_end()` loops over every account and calls `account.apply_monthly_effect()` without checking its type — savings accounts earn interest, checking accounts get charged a fee, same line of code. | New account types (e.g. `BusinessAccount`) can be added later without changing `Bank`'s code at all (open/closed principle). |
| **Clean code / SRP** | `Transaction` only records facts (immutable, frozen dataclass). `Account` only manages one account's state. `Bank` only coordinates multiple accounts. Custom exceptions (`InsufficientFundsError`, etc.) replace generic `Exception`/`ValueError`. | Each class has one reason to change; errors are self-documenting and easy to catch specifically. |

## Getting Started

```bash
git clone <your-repo-url>
cd banking_system
python3 main.py          # run the demo
python3 -m unittest discover -s tests -v   # run the tests
```

No external dependencies — standard library only (Python 3.10+ for the
`X | None` type hints; drop those or add `from __future__ import annotations`
for older versions if needed).

## Example Output

```
Opened: SavingsAccount ACC1001 (Alice Kumar) — balance: 1000.00
Opened: CheckingAccount ACC1002 (Bob Singh) — balance: 250.00

Expected error caught: Withdrawal would breach minimum balance of 100.00.

Running month-end interest/fees...
  [...] INTEREST      +      4.33 | balance:    1304.33 | Monthly interest
  [...] FEE           -      4.00 | balance:     346.00 | Monthly maintenance fee
```

## Possible Extensions

- Persistence layer (SQLite/JSON) behind a `Repository` interface
- `BusinessAccount` subclass with tiered fees
- Interest compounding schedules, CLI or REST API front end
- Role-based access (teller vs. account owner) as a separate concern from `Account`

## License

MIT — use freely for learning purposes.
