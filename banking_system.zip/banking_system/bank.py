"""
Bank: the top-level facade clients interact with. It owns the
collection of accounts and coordinates multi-account operations
(like transfers) so that individual Account objects never need to
know about each other.
"""
from __future__ import annotations
from typing import Dict, List, Literal

from exceptions import AccountNotFoundError, DuplicateAccountError, InvalidAmountError
from models import Account, SavingsAccount, CheckingAccount, Transaction, TransactionType


class Bank:
    def __init__(self, name: str):
        self.name = name
        self._accounts: Dict[str, Account] = {}

    # ---- account lifecycle ----
    def open_account(self, owner_name: str, kind: Literal["savings", "checking"],
                      initial_balance: float = 0.0, **kwargs) -> Account:
        if kind == "savings":
            account: Account = SavingsAccount(owner_name, initial_balance, **kwargs)
        elif kind == "checking":
            account = CheckingAccount(owner_name, initial_balance, **kwargs)
        else:
            raise ValueError(f"Unknown account kind: {kind!r}")

        if account.account_id in self._accounts:
            raise DuplicateAccountError(f"Account {account.account_id} already exists.")
        self._accounts[account.account_id] = account
        return account

    def get_account(self, account_id: str) -> Account:
        try:
            return self._accounts[account_id]
        except KeyError:
            raise AccountNotFoundError(f"No account with id {account_id!r}.")

    # ---- core operations (thin delegation — polymorphism does the work) ----
    def deposit(self, account_id: str, amount: float, description: str = "") -> Transaction:
        return self.get_account(account_id).deposit(amount, description)

    def withdraw(self, account_id: str, amount: float, description: str = "") -> Transaction:
        return self.get_account(account_id).withdraw(amount, description)

    def transfer(self, from_id: str, to_id: str, amount: float,
                 description: str = "") -> tuple[Transaction, Transaction]:
        if amount <= 0:
            raise InvalidAmountError("Transfer amount must be positive.")
        source = self.get_account(from_id)
        target = self.get_account(to_id)

        # withdraw() enforces the source account's own rules (min balance,
        # overdraft limit, etc.) via polymorphism — Bank doesn't need to
        # know which subtype `source` is.
        source.withdraw(amount, description or f"Transfer to {to_id}")
        out_tx = source._history[-1]
        # re-tag the just-recorded entry so the ledger reads TRANSFER_OUT
        # rather than a generic WITHDRAWAL
        source._history[-1] = Transaction(
            account_id=source.account_id, type=TransactionType.TRANSFER_OUT,
            amount=amount, balance_after=source.balance,
            description=out_tx.description,
        )

        target.deposit(amount, description or f"Transfer from {from_id}")
        in_tx = target._history[-1]
        target._history[-1] = Transaction(
            account_id=target.account_id, type=TransactionType.TRANSFER_IN,
            amount=amount, balance_after=target.balance,
            description=in_tx.description,
        )
        return source._history[-1], target._history[-1]

    def statement(self, account_id: str) -> List[Transaction]:
        return self.get_account(account_id).history

    def apply_month_end(self) -> List[Transaction]:
        """Runs interest/fees across every account — polymorphism in one loop."""
        results = []
        for account in self._accounts.values():
            tx = account.apply_monthly_effect()
            if tx:
                results.append(tx)
        return results

    def total_assets(self) -> float:
        return round(sum(a.balance for a in self._accounts.values()), 2)

    def list_accounts(self) -> List[Account]:
        return list(self._accounts.values())
