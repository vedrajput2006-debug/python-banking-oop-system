"""
Demo script — run with:  python main.py

Walks through opening accounts, deposits, withdrawals, a transfer,
month-end interest/fees, and printed statements.
"""
from bank import Bank
from exceptions import InsufficientFundsError, InvalidAmountError


def main():
    bank = Bank("Aster National Bank")

    alice = bank.open_account("Alice Kumar", "savings", initial_balance=1000,
                               interest_rate=0.04, minimum_balance=100)
    bob = bank.open_account("Bob Singh", "checking", initial_balance=250,
                             overdraft_limit=150, monthly_fee=4)

    print(f"Opened: {alice}")
    print(f"Opened: {bob}\n")

    bank.deposit(alice.account_id, 500, "Paycheck")
    bank.withdraw(bob.account_id, 100, "Groceries")

    try:
        bank.withdraw(alice.account_id, 5000, "Too much")
    except InsufficientFundsError as e:
        print(f"Expected error caught: {e}")

    bank.transfer(alice.account_id, bob.account_id, 200, "Rent split")

    print("\nRunning month-end interest/fees...")
    for tx in bank.apply_month_end():
        print(" ", tx)

    print(f"\n--- Statement for {alice.account_id} ---")
    for tx in bank.statement(alice.account_id):
        print(tx)

    print(f"\n--- Statement for {bob.account_id} ---")
    for tx in bank.statement(bob.account_id):
        print(tx)

    print(f"\nTotal assets under management: {bank.total_assets():.2f}")


if __name__ == "__main__":
    main()
