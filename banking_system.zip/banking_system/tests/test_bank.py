import sys, os, unittest
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from bank import Bank
from exceptions import InsufficientFundsError, InvalidAmountError


class TestBankingSystem(unittest.TestCase):
    def setUp(self):
        self.bank = Bank("Test Bank")
        self.savings = self.bank.open_account("Alice", "savings", 1000,
                                                interest_rate=0.06, minimum_balance=100)
        self.checking = self.bank.open_account("Bob", "checking", 200,
                                                 overdraft_limit=100, monthly_fee=5)

    def test_deposit_increases_balance(self):
        self.bank.deposit(self.savings.account_id, 250)
        self.assertEqual(self.savings.balance, 1250)

    def test_deposit_rejects_non_positive(self):
        with self.assertRaises(InvalidAmountError):
            self.bank.deposit(self.savings.account_id, 0)

    def test_savings_withdrawal_respects_minimum_balance(self):
        with self.assertRaises(InsufficientFundsError):
            self.bank.withdraw(self.savings.account_id, 950)  # would leave 50 < min 100

    def test_checking_allows_overdraft_within_limit(self):
        self.bank.withdraw(self.checking.account_id, 250)  # 200 - 250 = -50, within -100 limit
        self.assertEqual(self.checking.balance, -50)

    def test_checking_rejects_beyond_overdraft(self):
        with self.assertRaises(InsufficientFundsError):
            self.bank.withdraw(self.checking.account_id, 400)

    def test_transfer_moves_money_between_accounts(self):
        self.bank.transfer(self.savings.account_id, self.checking.account_id, 300)
        self.assertEqual(self.savings.balance, 700)
        self.assertEqual(self.checking.balance, 500)

    def test_month_end_applies_interest_and_fees(self):
        results = self.bank.apply_month_end()
        self.assertEqual(len(results), 2)  # one interest credit, one fee
        self.assertGreater(self.savings.balance, 1000)   # interest added
        self.assertEqual(self.checking.balance, 195)      # 200 - 5 fee

    def test_history_is_append_only_copy(self):
        history = self.savings.history
        history.append("tampered")
        self.assertNotIn("tampered", self.savings.history)

    def test_total_assets(self):
        self.assertEqual(self.bank.total_assets(), 1200)


if __name__ == "__main__":
    unittest.main()
